| `Version` | `Update Notes`                |
|-----------|-------------------------------|
| 1.0.1     | - Update for Valheim 0.217.22 |
| 1.0.0     | - Initial Release             |